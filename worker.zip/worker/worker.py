# worker.py
import os
import json
import time
import logging
from datetime import datetime
from azure.storage.queue import QueueClient
from utils import process_job_message, jobs_collection

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("worker")

AZURE_CONN = os.getenv("AZURE_STORAGE_CONNECTION_STRING")
QUEUE_NAME = os.getenv("STORAGE_QUEUE_NAME", "sow-jobs")
UPLOAD_CONTAINER = os.getenv("AZURE_BLOB_CONTAINER_UPLOADS", "uploads")
RESULTS_CONTAINER = os.getenv("AZURE_BLOB_CONTAINER_RESULTS", "results")

queue_client = QueueClient.from_connection_string(AZURE_CONN, QUEUE_NAME)

def handle_message(msg):
    try:
        body = json.loads(msg.content)
    except Exception:
        logger.exception("Invalid message, deleting")
        queue_client.delete_message(msg.id, msg.pop_receipt)
        return

    job_id = body.get("job_id")
    blob_name = body.get("blob_name")
    if not job_id or not blob_name:
        logger.error("Bad message payload; deleting")
        queue_client.delete_message(msg.id, msg.pop_receipt)
        return

    logger.info("Processing job %s", job_id)
    jobs_collection.update_one({"job_id": job_id}, {"$set": {
        "status": "processing",
        "updated_at": datetime.utcnow()
    }})

    ok = process_job_message(job_id, blob_name, AZURE_CONN, UPLOAD_CONTAINER, RESULTS_CONTAINER)

    if ok:
        logger.info("Job %s completed successfully", job_id)
        queue_client.delete_message(msg.id, msg.pop_receipt)
    else:
        logger.error("Job %s failed; leaving message for retry", job_id)

if __name__ == "__main__":
    logger.info("Worker started, polling queue...")
    while True:
        messages = queue_client.receive_messages(messages_per_page=5, visibility_timeout=120)
        found = False
        for msg in messages:
            found = True
            handle_message(msg)
        if not found:
            time.sleep(5)
