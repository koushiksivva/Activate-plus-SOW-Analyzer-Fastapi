#!/bin/bash
echo "Starting Python Worker..."
python3 worker.py
